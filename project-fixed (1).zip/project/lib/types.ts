export interface User {
  name: string;
  email: string;
  accountNumber: string;
  sortCode: string;
  avatarInitials: string;
}

export interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  recipient: string;
  category: TransactionCategory;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
  reference: string;
}

export type TransactionCategory =
  | 'transfer'
  | 'shopping'
  | 'food'
  | 'transport'
  | 'entertainment'
  | 'utilities'
  | 'salary'
  | 'other';

export interface CardSettings {
  frozen: boolean;
  contactless: boolean;
  onlinePayments: boolean;
}

export interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  balance: number;
  transactions: Transaction[];
  cardSettings: CardSettings;
}

export type TransferOutcome = 'success' | 'pending' | 'failed';

export interface TransferPayload {
  recipientName: string;
  amount: number;
  note?: string;
  outcome?: TransferOutcome;
  bankName?: string;
  bankFlag?: string;
}

export interface Receipt {
  id: string;
  status: 'completed' | 'pending' | 'failed';
  recipientName: string;
  amount: number;
  note: string;
  bankName: string;
  bankFlag: string;
  reference: string;
  timestamp: string;
  senderName: string;
  senderAccount: string;
  senderSortCode: string;
  newBalance: number;
  failureReason?: string;
}
