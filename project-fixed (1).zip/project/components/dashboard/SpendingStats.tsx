'use client';

import { TrendingUp, TrendingDown } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { formatCurrency } from '@/lib/formatters';

const CATEGORY_COLORS: Record<string, string> = {
  salary: 'bg-emerald-500',
  transfer: 'bg-blue-500',
  food: 'bg-orange-500',
  shopping: 'bg-pink-500',
  utilities: 'bg-amber-500',
  transport: 'bg-sky-500',
  entertainment: 'bg-violet-500',
  other: 'bg-slate-400',
};

const CATEGORY_LABELS: Record<string, string> = {
  salary: 'Salary',
  transfer: 'Transfers',
  food: 'Food',
  shopping: 'Shopping',
  utilities: 'Utilities',
  transport: 'Transport',
  entertainment: 'Entertainment',
  other: 'Other',
};

export function SpendingStats() {
  const { state } = useApp();

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const monthlyTxs = state.transactions.filter(
    (tx) => new Date(tx.timestamp) >= startOfMonth
  );

  const totalIn = monthlyTxs
    .filter((tx) => tx.type === 'credit')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalOut = monthlyTxs
    .filter((tx) => tx.type === 'debit')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const categoryTotals = monthlyTxs
    .filter((tx) => tx.type === 'debit')
    .reduce<Record<string, number>>((acc, tx) => {
      acc[tx.category] = (acc[tx.category] ?? 0) + tx.amount;
      return acc;
    }, {});

  const sortedCategories = Object.entries(categoryTotals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white rounded-xl border border-slate-100 px-3 py-2.5 shadow-sm flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0">
            <TrendingUp size={13} className="text-emerald-600" />
          </div>
          <div>
            <p className="text-[9px] font-semibold text-slate-500 uppercase tracking-wide">Money In</p>
            <p className="text-sm font-bold text-emerald-700 leading-tight">{formatCurrency(totalIn)}</p>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-100 px-3 py-2.5 shadow-sm flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-rose-50 flex items-center justify-center flex-shrink-0">
            <TrendingDown size={13} className="text-rose-500" />
          </div>
          <div>
            <p className="text-[9px] font-semibold text-slate-500 uppercase tracking-wide">Money Out</p>
            <p className="text-sm font-bold text-rose-600 leading-tight">{formatCurrency(totalOut)}</p>
          </div>
        </div>
      </div>

      {sortedCategories.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-100 px-3 py-2.5 shadow-sm">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-2">Top Spending</p>
          <div className="space-y-1.5">
            {sortedCategories.map(([cat, amount]) => {
              const pct = totalOut > 0 ? (amount / totalOut) * 100 : 0;
              return (
                <div key={cat} className="space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-medium text-slate-600">{CATEGORY_LABELS[cat] ?? cat}</span>
                    <span className="text-[10px] font-semibold text-slate-800">{formatCurrency(amount)}</span>
                  </div>
                  <div className="h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${CATEGORY_COLORS[cat] ?? 'bg-slate-400'}`}
                      style={{ width: `${Math.max(pct, 4)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
