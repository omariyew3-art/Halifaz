'use client';

import { useState } from 'react';
import { Search } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { formatCurrency, formatDate, formatTime } from '@/lib/formatters';
import { Transaction } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { TransactionDetail } from './TransactionDetail';

const CATEGORY_COLORS: Record<string, string> = {
  salary: 'bg-emerald-50 text-emerald-700 border-emerald-100',
  entertainment: 'bg-violet-50 text-violet-700 border-violet-100',
  food: 'bg-orange-50 text-orange-700 border-orange-100',
  transport: 'bg-sky-50 text-sky-700 border-sky-100',
  transfer: 'bg-blue-50 text-blue-700 border-blue-100',
  utilities: 'bg-amber-50 text-amber-700 border-amber-100',
  shopping: 'bg-pink-50 text-pink-700 border-pink-100',
  other: 'bg-slate-50 text-slate-700 border-slate-100',
};

const CATEGORY_EMOJI: Record<string, string> = {
  salary: '💼',
  entertainment: '🎬',
  food: '🍔',
  transport: '🚗',
  transfer: '↗',
  utilities: '⚡',
  shopping: '🛍️',
  other: '📦',
};

function groupByDate(transactions: Transaction[]): Record<string, Transaction[]> {
  return transactions.reduce<Record<string, Transaction[]>>((acc, tx) => {
    const key = formatDate(tx.timestamp);
    if (!acc[key]) acc[key] = [];
    acc[key].push(tx);
    return acc;
  }, {});
}

interface TransactionListProps {
  limit?: number;
  showSearch?: boolean;
}

export function TransactionList({ limit, showSearch = true }: TransactionListProps) {
  const { state } = useApp();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'credit' | 'debit'>('all');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const handleRowClick = (tx: Transaction) => {
    setSelectedTx(tx);
    setDetailOpen(true);
  };

  const filtered = state.transactions.filter((tx) => {
    const matchesSearch =
      tx.description.toLowerCase().includes(search.toLowerCase()) ||
      (tx.recipient ?? '').toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' || tx.type === filter;
    return matchesSearch && matchesFilter;
  });

  const displayed = limit ? filtered.slice(0, limit) : filtered;
  const grouped = groupByDate(displayed);
  const groupKeys = Object.keys(grouped);

  return (
    <>
      <div className="space-y-4">
        {showSearch && (
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input
                placeholder="Search transactions..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 rounded-xl border-slate-200 bg-slate-50 h-10 text-sm focus-visible:ring-blue-500"
              />
            </div>
            <div className="flex rounded-xl border border-slate-200 bg-slate-50 overflow-hidden p-0.5 gap-0.5">
              {(['all', 'credit', 'debit'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 h-8 text-xs font-medium rounded-lg capitalize transition-all ${
                    filter === f ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        )}

        {displayed.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mx-auto mb-3">
              <Search size={22} className="text-slate-300" />
            </div>
            <p className="text-sm font-medium">No transactions found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {groupKeys.map((dateLabel) => (
              <div key={dateLabel}>
                <p className="text-[9px] font-semibold text-slate-400 uppercase tracking-wider mb-1.5 px-1">{dateLabel}</p>
                <div className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-sm divide-y divide-slate-50">
                  {grouped[dateLabel].map((tx) => (
                    <TransactionRow key={tx.id} transaction={tx} onClick={() => handleRowClick(tx)} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <TransactionDetail
        transaction={selectedTx}
        open={detailOpen}
        onOpenChange={setDetailOpen}
      />
    </>
  );
}

function TransactionRow({ transaction: tx, onClick }: { transaction: Transaction; onClick: () => void }) {
  const isCredit = tx.type === 'credit';
  const emoji = CATEGORY_EMOJI[tx.category] ?? '📦';
  const categoryColor = CATEGORY_COLORS[tx.category] ?? CATEGORY_COLORS.other;

  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-2.5 px-3 py-2.5 hover:bg-slate-50/80 transition-colors cursor-pointer group text-left"
    >
      <div className="w-8 h-8 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-sm flex-shrink-0 group-hover:scale-105 transition-transform">
        {emoji}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold text-slate-800 truncate">{tx.description}</p>
        <p className="text-[10px] text-slate-400 truncate">{tx.recipient ?? 'Halifax'} · {formatTime(tx.timestamp)}</p>
      </div>

      <div className="text-right flex-shrink-0">
        <p className={`text-xs font-bold ${isCredit ? 'text-emerald-600' : 'text-slate-800'}`}>
          {isCredit ? '+' : '−'}{formatCurrency(tx.amount)}
        </p>
        <span className={`text-[9px] font-medium px-1 py-0.5 rounded border ${categoryColor}`}>
          {tx.category}
        </span>
      </div>
    </button>
  );
}
