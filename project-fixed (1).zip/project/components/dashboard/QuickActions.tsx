'use client';

import { ArrowUpRight, ArrowDownLeft, LayoutList, Plus } from 'lucide-react';

interface QuickActionsProps {
  onSend: () => void;
  onReceive: () => void;
  onTransactions: () => void;
  onTopUp: () => void;
}

const actions = [
  {
    key: 'send',
    label: 'Send',
    icon: ArrowUpRight,
    bg: 'bg-blue-600 hover:bg-blue-700',
    iconBg: 'bg-blue-500',
    textColor: 'text-white',
  },
  {
    key: 'receive',
    label: 'Receive',
    icon: ArrowDownLeft,
    bg: 'bg-emerald-500 hover:bg-emerald-600',
    iconBg: 'bg-emerald-400',
    textColor: 'text-white',
  },
  {
    key: 'transactions',
    label: 'History',
    icon: LayoutList,
    bg: 'bg-slate-100 hover:bg-slate-200',
    iconBg: 'bg-white',
    textColor: 'text-slate-700',
  },
  {
    key: 'topup',
    label: 'Top Up',
    icon: Plus,
    bg: 'bg-slate-100 hover:bg-slate-200',
    iconBg: 'bg-white',
    textColor: 'text-slate-700',
  },
];

export function QuickActions({ onSend, onReceive, onTransactions, onTopUp }: QuickActionsProps) {
  const handlers: Record<string, () => void> = {
    send: onSend,
    receive: onReceive,
    transactions: onTransactions,
    topup: onTopUp,
  };

  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map(({ key, label, icon: Icon, bg, iconBg, textColor }) => (
        <button
          key={key}
          onClick={handlers[key]}
          className={`flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all duration-150 active:scale-95 shadow-sm ${bg}`}
        >
          <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center shadow-sm`}>
            <Icon size={15} className={textColor === 'text-white' ? 'text-white' : 'text-slate-600'} strokeWidth={2.5} />
          </div>
          <span className={`text-[10px] font-semibold ${textColor}`}>{label}</span>
        </button>
      ))}
    </div>
  );
}
