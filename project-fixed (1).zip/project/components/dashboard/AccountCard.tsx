'use client';

import { useState } from 'react';
import { Eye, EyeOff, Copy, Check, Wifi } from 'lucide-react';
import { useApp } from '@/store/AppContext';
import { formatCurrency } from '@/lib/formatters';

export function AccountCard() {
  const { state } = useApp();
  const [balanceHidden, setBalanceHidden] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const accountNumber = state.user?.accountNumber;
    if (!accountNumber) return;
    navigator.clipboard.writeText(accountNumber).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden shadow-xl select-none">
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 40%, #2563eb 65%, #3b82f6 100%)',
        }}
      />
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 80% 20%, rgba(255,255,255,0.4) 0%, transparent 50%),
                            radial-gradient(circle at 20% 80%, rgba(255,255,255,0.15) 0%, transparent 50%)`,
        }}
      />
      <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/5 -translate-y-1/2 translate-x-1/4" />
      <div className="absolute bottom-0 left-0 w-28 h-28 rounded-full bg-white/5 translate-y-1/2 -translate-x-1/4" />

      <div className="relative px-4 pt-4 pb-3 text-white z-10">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-blue-200 text-[9px] font-medium uppercase tracking-widest mb-0.5">Halifax Digital Bank</p>
            <p className="text-white/90 font-semibold text-sm">{state.user?.name}</p>
          </div>
          <Wifi size={14} className="text-white/60 rotate-90 mt-0.5" />
        </div>

        <div className="mb-3">
          <p className="text-blue-200 text-[9px] uppercase tracking-widest mb-1">Available Balance</p>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold tracking-tight">
              {balanceHidden ? '£ ••••••' : formatCurrency(state.balance)}
            </p>
            <button
              onClick={() => setBalanceHidden(!balanceHidden)}
              className="p-1 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
            >
              {balanceHidden ? <Eye size={13} /> : <EyeOff size={13} />}
            </button>
          </div>
        </div>

        <div className="flex items-end justify-between">
          <div>
            <p className="text-blue-200 text-[9px] uppercase tracking-widest mb-0.5">Account Number</p>
            <div className="flex items-center gap-1.5">
              <p className="font-mono text-xs font-medium tracking-wider">{state.user?.accountNumber}</p>
              <button
                onClick={handleCopy}
                className="p-0.5 rounded bg-white/10 hover:bg-white/20 transition-colors"
              >
                {copied ? <Check size={10} /> : <Copy size={10} />}
              </button>
            </div>
          </div>
          <div className="text-center">
            <p className="text-blue-200 text-[9px] uppercase tracking-widest mb-0.5">Sort Code</p>
            <p className="font-mono text-xs font-medium tracking-wider">{state.user?.sortCode}</p>
          </div>
          <div className="flex -space-x-1.5">
            <div className="w-6 h-6 rounded-full bg-yellow-400/80 border-2 border-blue-700" />
            <div className="w-6 h-6 rounded-full bg-orange-500/80 border-2 border-blue-700" />
          </div>
        </div>
      </div>
    </div>
  );
}
